import 'package:flutter/material.dart';
import 'add_task.dart';
import 'settings.dart';
import 'timer.dart';
import 'reminders.dart';

class TasksPage extends StatefulWidget {
  const TasksPage({super.key});

  @override
  State<TasksPage> createState() => _TasksPageState();
}

class _TasksPageState extends State<TasksPage> {
  String selectedFilter = 'All Tasks';
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    if (index == 1) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const TimerPage()),
      );
    } else if (index == 2) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const RemindersPage()),
      );
    } else if (index == 3) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const SettingsScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: PopupMenuButton<String>(
          icon: const Icon(Icons.menu, color: Colors.black),
          onSelected: (value) {
            setState(() {
              selectedFilter = value;
            });
          },
          itemBuilder: (BuildContext context) => [
            const PopupMenuItem(value: 'All Tasks', child: Text('All Tasks')),
            const PopupMenuItem(value: 'Today', child: Text('Today')),
            const PopupMenuItem(value: 'Completed today', child: Text('Completed today')),
            const PopupMenuItem(value: 'Not done', child: Text('Not done')),
          ],
        ),
        title: Text(
          selectedFilter,
          style: const TextStyle(color: Colors.black),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          const SizedBox(height: 20),
          OutlinedButton.icon(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const AddTaskPage()),
              );
            },
            icon: const Icon(Icons.add),
            label: const Text("Add Task"),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size(150, 40),
              side: const BorderSide(color: Colors.black),
            ),
          ),
          const SizedBox(height: 80),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.image,
                size: 80,
                color: Colors.grey[700],
              ),
              const SizedBox(height: 20),
              const Text(
                "Your journey starts\nwith a single step",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.black87,
                ),
              ),
            ],
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.star_outline),
            label: "Routine",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.access_time),
            label: "Timer",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.alarm),
            label: "Reminders",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            label: "Profile",
          ),
        ],
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),
    );
  }
}



